#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <stdlib.h>
int main(int argc, const char *argv[])
{
	int key;
	int shmid;
	char *addr;
	char buf[1024] = {0};

	key = ftok("/home/linux",'k');
	if(key == -1){
		perror("ftok get errror");
		exit(EXIT_FAILURE);
	}
	
	shmid = shmget(key,1024,IPC_CREAT|0666);
	if(shmid == -1){
		perror("get shmget id error");
		exit(EXIT_FAILURE);
	}

	addr = (char *)shmat(shmid,NULL,0);
	if(addr == NULL){
		perror("share memory map error");
		exit(EXIT_FAILURE);
	
	}
	printf("input>");
	fgets(buf,sizeof(buf),stdin);
	buf[strlen(buf)-1] = '\0';
	
	memcpy(addr,buf,sizeof(buf));


	shmdt(addr);

	return 0;
}
