#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <string.h>

struct msgbuf {
	long mtype;       /* message type, must be > 0 */
	char mtext[1024];    /* message data */
};

int main(int argc, const char *argv[])
{
	int key;
	int msgid;
	struct msgbuf msgq;

	key = ftok("/home/linux",'k');
	if(key == -1){
		perror("get key error");
		exit(EXIT_FAILURE);	
	}

	msgid = msgget(key,IPC_CREAT|0666);
	if(msgid == -1){
		perror("msg get id error");
		exit(EXIT_FAILURE);
	}
	msgq.mtype = 'a';
	while(1){
		if(msgrcv(msgid, (void *)&msgq, sizeof(msgq.mtext),msgq.mtype, 0) == -1){
			perror("send msg error");
			exit(EXIT_FAILURE);

		}
		if(strcmp(msgq.mtext,"quit") == 0) break;
		printf("read data = %s\n",msgq.mtext);
	}
	msgctl(msgid,IPC_RMID,0);
	return 0;
}
