#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <signal.h>
#define SIZE 1024
#define READ 0
#define WRITE 1
union semun {
	int              val;    /* Value for SETVAL */
	struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
	unsigned short  *array;  /* Array for GETALL, SETALL */
	struct seminfo  *__buf;  /* Buffer for IPC_INFO
								(Linux-specific) */
};

void init_semaphore(int semid,char *sem,int n)
{
	int i;
	union semun semun;
	for(i=0; i<n; i++){
		semun.val = sem[i];
		if(semctl(semid,i,SETVAL,semun) == -1){
			perror("sem init error");
			exit(EXIT_FAILURE);
		}
	}
}

void  p(int semid,int which)
{
	struct sembuf buf;
	buf.sem_num = which;
	buf.sem_op = -1;
	buf.sem_flg = 0;
	if(semop(semid,&buf,1) == -1){
		perror("p error");
		exit(EXIT_FAILURE);
	}
}

void  v(int semid,int which)
{
	struct sembuf buf;
	buf.sem_num = which;
	buf.sem_op = 1;
	buf.sem_flg = 0;
	if(semop(semid,&buf,1) == -1){
		perror("p error");
		exit(EXIT_FAILURE);
	}
}

int main(int argc, const char *argv[])
{
	
	int key,semid,shmid,nsems = 2;
	char *shmaddr;
	char *t,*q;
	pid_t pid;
	char sem[] = {0,1}; //0 read 1 write

	key = ftok("/home/linux",'t');
	if(key == -1){
		perror("key create fail");
		exit(EXIT_FAILURE);
	}
	
	semid = semget(key,nsems,IPC_CREAT|0666);
	if(semid == -1){
		perror("semaphore create failed");
		exit(EXIT_FAILURE);
	}
	
	shmid = shmget(key,SIZE,IPC_CREAT|0666);
	if(shmid == -1){
		perror("error shmget");
		goto ERR1;
	}
	
	shmaddr = (char *)shmat(shmid,NULL,0);
	if(shmaddr == (char *)-1){
		perror("error shmat");
		goto ERR2;
	}
	
	init_semaphore(semid,sem,nsems);

	if((pid = fork())<0){
		perror("fork");
		goto ERR2;
	}else if(pid == 0 ){
		while(1){
			t = q = shmaddr;
			p(semid,READ);
			while(*t){
				if(*t != ' '){
					*q++ = *t;	
				}
				t++;
			}	
			*q = '\0';
			printf("read data = %s",shmaddr);
			v(semid,WRITE);
		}
	}else{
		while(1){
			p(semid,WRITE);
			printf("input> ");
			fgets(shmaddr,SIZE,stdin);
			if(strcmp(shmaddr,"quit\n") == 0)break;
			v(semid,READ);
		}
		kill(pid,SIGUSR1);
	}

ERR2:
	shmctl(shmid,IPC_RMID,0);

ERR1:
	semctl(semid,nsems,IPC_RMID,0);
	return 0;

}
