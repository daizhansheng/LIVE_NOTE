#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>

int main(int argc, const char *argv[])
{
	pid_t pid;
	int val = 0;
	int sv[2] = {0};
	if((socketpair(AF_UNIX,SOCK_STREAM, 0,sv))<0){
		perror("socketpair error");
		exit(1);
	}

	pid = fork();
	if(pid < 0){
		perror("fork error");
		exit(1);
	}else if(pid == 0){
		while(1){
			printf("start:%d\n",val);
			val++;
			write(sv[0],&val,sizeof(val));
			read(sv[0],&val,sizeof(val));
			printf("end:%d\n",val);

		}
			
	}else{
		while(1){
			sleep(3);
			read(sv[1],&val,sizeof(val));
			val++;
			write(sv[1],&val,sizeof(val));
		}
	}

	return 0;
}
