#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/leds.h>
#include <linux/gpio.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <asm/io.h>

//GPX1_1
#define GPX1_CON  0x11000c20 
#define GPX1_DAT  0x11000c24
unsigned int *pad_con = NULL;
unsigned int *pad_dat = NULL;


struct led_classdev *fspad_led = NULL;

void fspad_brightness_set(struct led_classdev *led_cdev,
							enum led_brightness brightness)
{
	if(brightness == LED_OFF){
		writel((readl(pad_dat)&(~(1<<0))),pad_dat);
	}else{
		writel((readl(pad_dat)|(1<<0)),pad_dat);
	}
}

static int __init fspad_led_init(void)
{
	int ret;
	//Ϊ�ṹ�����ռ�
	fspad_led = kzalloc(sizeof(*fspad_led),GFP_KERNEL);
	if(fspad_led == NULL){
		printk("Can not allocate Buffer\n");
		return -ENOMEM;
	}

	//�ṹ��ĳ�ʼ��
	fspad_led->name = "led1";
	fspad_led->brightness =LED_FULL;
	fspad_led->flags =LED_CORE_SUSPENDRESUME ;
	fspad_led->brightness_set = fspad_brightness_set;

	//ӳ���ַ�����õ�Ϊ�ر�״̬
	pad_con = (unsigned int *)ioremap(GPX1_CON,4);	
	pad_dat = (unsigned int *)ioremap(GPX1_DAT,4);		
	writel(((readl(pad_con)&(~(0xf<<0)))|(1<<0)),pad_con);	
	writel((readl(pad_dat)&(~(1<<0))),pad_dat);

	//ע��ṹ��
	ret = led_classdev_register(NULL, fspad_led);
	if (ret < 0)
		printk("led_classdev_register failed\n");
	
	return 0;
}

static void __exit fspad_led_exit(void)
{
	kfree(fspad_led);
	iounmap(pad_con);
	iounmap(pad_dat);
	led_classdev_unregister(fspad_led);
}

module_init(fspad_led_init);
module_exit(fspad_led_exit);
MODULE_LICENSE("GPL");


