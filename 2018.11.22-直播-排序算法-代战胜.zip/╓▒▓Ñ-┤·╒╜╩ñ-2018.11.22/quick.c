#include <stdio.h>

#define ARRAY_SIZE(buf) (sizeof(buf)/sizeof(buf[0]))

void show(int *buf,int max)
{
	int i;
	for(i=0; i<max; i++) printf("%d\t",buf[i]);
	printf("\n");
}

void swap(int *a,int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void quick(int *buf,int start,int end)
{
	int i,j;
	if(start < end){
		i = start;
		j = end;
		while(i<j){
			while(i<j && buf[i]<buf[j]){
				j--;
			}
			if(i<j){
				swap(&buf[i],&buf[j]);
				i++;
			}

			while(i<j && buf[i]<buf[j]){
				i++;
			}
			if(i<j){
				swap(&buf[i],&buf[j]);
				j--;
			}
		}
		quick(buf,start,i-1);
		quick(buf,i+1,end);
	}
	
}

int main(int argc, const char *argv[])
{
	int buf[9] = {3,6,5,9,7,1,8,2,4};
	
	quick(buf,0,ARRAY_SIZE(buf));

	show(buf,ARRAY_SIZE(buf));
	
	return 0;
}
