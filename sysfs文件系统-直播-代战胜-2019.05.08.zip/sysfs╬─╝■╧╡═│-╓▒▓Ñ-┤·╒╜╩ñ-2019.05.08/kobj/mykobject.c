#include <linux/init.h>
#include <linux/module.h>
#include <linux/kobject.h>

struct kobject kobj;

char attr_buf[256];
struct attribute attr = {
	.name = "hello",
	.mode = 0775,
};

ssize_t mykobject_show(struct kobject *kobj, 
	struct attribute *attr, char *buf)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	memcpy(buf,attr_buf,strlen(attr_buf));
	return strlen(attr_buf); //���ص��Ƕ�ȡ���Լ��ĸ���

}
ssize_t mykobject_store(struct kobject *kobj, 
	struct attribute *attr, const char *buf, size_t size)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	memcpy(attr_buf,buf,size);
	printk("write:%s\n",attr_buf);
	return size; //���ص���д���ֽڵĸ���

}


struct attribute *mykobject_default_attrs[] = {
	&attr,
	NULL
};

const struct sysfs_ops mykobject_sysfs_ops = {
	.show = mykobject_show,
	.store = mykobject_store,
};

void mykobject_relesse(struct kobject *kobj)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
}

struct kobj_type ktype = {
	.release       = mykobject_relesse,
	.sysfs_ops     = &mykobject_sysfs_ops,
	.default_attrs = mykobject_default_attrs,
};

static int __init mykobject_init(void)
{
	return kobject_init_and_add(&kobj,&ktype,NULL,"test");
}
static void __exit mykobject_exit(void)
{
	kobject_del(&kobj);
}
module_init(mykobject_init);
module_exit(mykobject_exit);
MODULE_LICENSE("GPL");







