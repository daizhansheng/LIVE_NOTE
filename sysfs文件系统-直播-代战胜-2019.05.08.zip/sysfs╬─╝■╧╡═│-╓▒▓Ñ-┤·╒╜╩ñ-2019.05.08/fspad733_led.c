#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>

#include <asm/io.h>

#include "fspad733_led.h"

//register of the pin using for led
#define FSPAD733_GPFCON	0x01C208B4
#define FSPAD733_GPFDAT	0x01C208C4

//license information
MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("farsight");

//the major and minor id
static int led_major = 500;
static int led_minor = 0;

//this is an cdev type device
static struct cdev led_cdev;

//the pointer of the led
static unsigned int *gpfcon;
static unsigned int *gpfdat;

//class of led device
struct class *led_class;

/**
 * init the register
 */
static void led_init(void)
{
	writel((readl(gpfcon) & ~(0xf << 8)) | (0x1 << 8), gpfcon);
}

/**
 * reset the register
 */
static void led_recovery(void)
{
	writel((readl(gpfcon) & ~(0xf << 8)) | (0x3 << 8), gpfcon);
}

/**
 * set led ON
 */
static void led_on(void)
{
	writel(readl(gpfdat) & ~(0x1 << 2), gpfdat);
}

/**
 * set led OFF
 */
static void led_off(void)
{
	writel(readl(gpfdat) | (0x1 << 2), gpfdat);
}

/**
 * open the led device
 * in this fonction do noting 
 * because the pin using for LED is multiplexing using for UART
 * so anyway using this pin should init and reset the register
 * init while opening the device may cause some error
 */
static int fspad733_led_open(struct inode *inode, struct file *file)
{
	printk("led: device open\n");
//	led_init();
	return 0;
}

/**
 * close is equal as reset
 */
static int fspad733_led_close(struct inode *inode, struct file *file)
{
	printk("led: device close\n");
	led_recovery();
	return 0;
}

/**
 * use ioctl type for control the led device
 */
static long fspad733_led_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	printk("led: device ioctl\n");
	switch(cmd)
	{
	case LED_ON:
		printk("led: ON\n");
		led_init();
		led_on();
		break;
	case LED_OFF:
		printk("led: OFF\n");
		led_off();
		led_recovery();
		break;
	default:
		printk("led: available command\n");
		break;
	}
	return 0;
}

/**
 * file_operations struct
 */
static struct file_operations fspad733_led_ops = {
	.owner 				= THIS_MODULE,
	.open 				= fspad733_led_open,
	.release 			= fspad733_led_close,
	.unlocked_ioctl		= fspad733_led_ioctl
};

/**
 * setup for cdev
 */
static int led_setup_cdev(struct cdev *cdev, 
		struct file_operations *fops)
{
	int result;
	dev_t devno = MKDEV(led_major, led_minor);
	cdev_init(cdev, fops);
	cdev->owner = THIS_MODULE;
	result = cdev_add(cdev, devno, 1);
	if(result)
	{
		printk("led: cdev add failed\n");
		return result;
	}
	return 0;
}

/**
 * do ontiong
 */
static ssize_t fspad733_led_enable_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	return 0;
}
/**
 * this is the same as the operate on ioctl type
 */
static ssize_t fspad733_led_enable_store(struct device *dev,
		struct device_attribute *attr,
		const char *buf, size_t count)
{
	unsigned long data;
	int error;

	error = strict_strtoul(buf, 10, &data);
	printk("set value = %d\n", data);

	if (error)
		return error;

	if (data == 1) {
		printk("turn on\n");
		led_init();
		led_on();
	}
	else {
		printk("turn off\n");
		led_off();
		led_recovery();
	}

	return count;
}

//DEVICE_ATTR
static DEVICE_ATTR(enable, 0777,
		fspad733_led_enable_show, fspad733_led_enable_store);
//attribute table
static struct attribute *fspad733_led_attributes[] = {
	&dev_attr_enable.attr,
	NULL,
};
//group of attr
static struct attribute_group fspad733_led_attributes_group = {
	.attrs = fspad733_led_attributes
};
//device	
struct device *dev;
//deivce init
static int __init fspad733_led_init(void)
{
	int result;
	dev_t devno = MKDEV(led_major, led_minor);
	result = register_chrdev_region(devno, 1, "fspad733_led");
	if(result){
		printk("led: unable to get major %d\n", led_major);
		return result;
	}

	result = led_setup_cdev(&led_cdev, &fspad733_led_ops);
	if(result) {
		printk("led: failed in cdev add.\n");
		unregister_chrdev_region(devno, 1);
		return result;
	}

	gpfcon = ioremap(FSPAD733_GPFCON, 4);
	if (gpfcon == NULL) {
		printk("led: failed in ioremap.\n");
		goto err1;
	}
	
	gpfdat = ioremap(FSPAD733_GPFDAT, 4);
	if (gpfcon == NULL) {
		printk("led: failed in ioremap.\n");
		goto err2;
	}

	led_class = class_create(THIS_MODULE, "farsight_led");
	if (IS_ERR(led_class)) {
		printk("led: failed in creating class.\n");
		goto err3;
	}
	
	dev = device_create(led_class, NULL, devno, NULL, "led");

	result = sysfs_create_group(&dev->kobj,
						 &fspad733_led_attributes_group);
	if (result < 0)
	{
		printk("led: sysfs_create_group err\n");
		goto err3;
	}


	printk("led: driver installed, with major %d!\n", led_major);
	return 0;
err3:
	iounmap(gpfdat);
err2:
	iounmap(gpfcon);
err1:
	cdev_del(&led_cdev);
	unregister_chrdev_region(devno, 1);

	return result;
}
//deivce unregister
static void __exit fspad733_led_exit(void)
{
	dev_t devno = MKDEV(led_major, led_minor);
	sysfs_remove_group(&dev->kobj, &fspad733_led_attributes_group);
	device_destroy(led_class, devno);
	class_destroy(led_class);
	iounmap(gpfdat);
	iounmap(gpfcon);
	cdev_del(&led_cdev);
	unregister_chrdev_region(devno, 1);
	printk("led: driver uninstalled!\n");
}

module_init(fspad733_led_init);
module_exit(fspad733_led_exit);
