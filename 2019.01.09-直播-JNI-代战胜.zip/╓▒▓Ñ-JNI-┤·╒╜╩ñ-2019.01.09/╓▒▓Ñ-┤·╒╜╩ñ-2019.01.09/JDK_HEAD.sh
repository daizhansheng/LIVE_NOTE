SRCDIR=/usr/lib/jdk/jdk1.8.0_191/include
DESTDIR=/usr/include
cd /usr/lib/jdk/jdk1.8.0_191/include/
includeall='ls *.h'
for file in $includeall
	do
	if [ $file != "ls" ]; then
		echo $file
			ln -s $SRCDIR/$file $DESTDIR/$file
	fi
	done

cd ./linux/
linuxall='ls *.h'

for file in $linuxall
	do
	if [ $file != "ls" ]; then
		echo $file
			ln -s $SRCDIR/linux/$file $DESTDIR/$file
	fi
	done
