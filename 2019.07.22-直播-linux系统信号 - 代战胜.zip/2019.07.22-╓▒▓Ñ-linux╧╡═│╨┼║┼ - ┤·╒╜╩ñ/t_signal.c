#include <stdio.h>
#include <signal.h>

void handle_sig(int num)
{
	sleep(5);
	printf("sgino = %d,handle signal....\n",num);
}

int main(int argc, const char *argv[])
{
	
	printf("PID = %d\n",getpid());

	if(signal(SIGUSR1,handle_sig) == SIG_ERR){
		perror("register signal error");
		return -1;
	}

	while(1)sleep(1);
	return 0;
}
