#include <stdio.h>
#include <signal.h>

void handle_sigaction(int num)
{
	sleep(2);
	 printf("sgino = %d,handle signal....\n",num);
}

int main(int argc, const char *argv[])
{
	struct sigaction sig;
	printf("PID:%d\n",getpid());
	sig.sa_handler = handle_sigaction;
	//sig.sa_flags = SA_RESETHAND|SA_NODEFER;
	//sig.sa_flags = SA_NODEFER;
	sig.sa_flags = 0;
	sigaction(SIGINT, &sig,NULL);

	while(1){
		sleep(1);
	}

	return 0;
}
