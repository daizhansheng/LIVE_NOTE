#include <linux/init.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/input.h>

struct timer_list timer;
//0.����������ϵͳ����
struct input_dev *input;

void timer_function(unsigned long data)
{
	static int value = 0;
	value = value?0:1;
	//4.�ϱ�����
	input_report_key(input,KEY_L,value);
	input_report_key(input,KEY_S,value);
	input_report_key(input,KEY_ENTER,value);
	input_sync(input);

	mod_timer(&timer,jiffies+HZ);
}

static int __init timer_input_init(void)
{	
	int ret;
	//1.�����ڴ�ռ�
	input = input_allocate_device();
	if(input == NULL){
		printk("alloc input memory error\n");
		return -ENOMEM;
	}
	//2.������ϵͳ��ʼ��
	//2.1�¼�����Ϊ�����¼�
	set_bit(EV_KEY,input->evbit);
	set_bit(EV_SYN,input->evbit);
	//2.2�����Ǹ�����
	set_bit(KEY_L,input->keybit);
	set_bit(KEY_S,input->keybit);
	set_bit(KEY_ENTER,input->keybit);

	//3.ע��
	ret = input_register_device(input);
	if(ret){
		printk("register input error\n");
		return -EAGAIN;
	}
	
	timer.expires = jiffies+HZ;
	timer.function = timer_function;
	timer.data = 0;
	init_timer(&timer);
	add_timer(&timer);
	return 0;
}
static void __exit timer_input_exit(void)
{
	del_timer(&timer);
	input_unregister_device(input);
	input_free_device(input);
}
module_init(timer_input_init);
module_exit(timer_input_exit);
MODULE_LICENSE("GPL");







