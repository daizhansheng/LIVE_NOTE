#include <stdio.h>
#include <sys/inotify.h>
#include <unistd.h>


struct inotify_event event[10];

int main(int argc, const char *argv[])
{
	int ify_fd,wfd,ret,i;

	if((ify_fd = inotify_init()) == -1){
		perror("create inotify instance error\n");
		return -1;
	}

	if((wfd = inotify_add_watch(ify_fd,"/home/linux/", IN_CREATE|IN_DELETE)) == -1){
		perror("create inotify watch instance error\n");
		return -1;
	}

	while(1){
		ret = read(ify_fd,event,sizeof(event));
		if(ret == -1){
			perror("read error\n");
			return -1;
		}else{
			for(i=0; i<ret/sizeof(struct inotify_event); i++){
				if((event[i].wd == wfd) && (event[i].mask & IN_CREATE) ){
					printf("create file name %s\n",event[i].name);
				}
				if((event[i].wd == wfd) && (event[i].mask & IN_DELETE) ){
					printf("delete file name %s\n",event[i].name);
				}
			}
		}
	}

	return 0;
}
