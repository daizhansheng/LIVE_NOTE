#include <stdio.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define N_B 1024
#define N_S 20
struct name_to_fd
{
	int fd;
	char name[N_B];
};

char buf[N_B];
char name_buf[N_B];
struct name_to_fd name_to_fd[N_B];
struct epoll_event event;
struct epoll_event revents[N_S];
struct inotify_event i_event[N_S];

int main(int argc, const char *argv[])
{
	int ret,e_ret,t_ret,r_ret;
	int i,t,n;
	int ify_fd,wfd,epfd,fd;

	if((epfd = epoll_create(10)) == -1){
		perror("create inotify instance error");
		return -1;	
	}

	if((ify_fd = inotify_init()) == -1){
		perror("create inotify instance error");
		return -1;
	}

	if((wfd = inotify_add_watch(ify_fd,"/home/linux/", IN_CREATE|IN_DELETE)) == -1){
		perror("create inotify watch instance error");
		return -1;
	}
	event.events = EPOLLIN;
	event.data.fd = ify_fd;
	if((ret = epoll_ctl(epfd, EPOLL_CTL_ADD, ify_fd, &event)) == -1){
		perror("epoll ctl error");
		return -1;
	}

	while(1){
		 ret = epoll_wait(epfd,revents,20,-1);
		 if(ret == -1){
		 	perror("epoll wait");
			return -1;
		 }else{
		 	for(i=0; i<ret; i++){
				if((revents[i].events & EPOLLIN) && (revents[i].data.fd == ify_fd)){
					r_ret = read(ify_fd,i_event,sizeof(i_event));
					if(r_ret == -1){
						perror("read i_event");
						return -1;
					}else{
						for(t=0; t<r_ret/sizeof(struct inotify_event); t++){
							if(i_event[t].mask & IN_CREATE){
								printf("create file name = %s\n",i_event[t].name);
								memset(name_buf,0,sizeof(name_buf));
								sprintf(name_buf,"/home/linux/%s",i_event[t].name);
								if((fd = open(name_buf,O_RDWR)) == -1){
									perror("open");
									return -1;
								}
								name_to_fd[fd].fd = fd;
								strcpy(name_to_fd[fd].name,i_event[t].name);
								event.events = EPOLLIN;
								event.data.fd = fd;
								if((epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event)) == -1){
									perror("epoll ctl error");
									return -1;
								}
							}else if(i_event[t].mask & IN_DELETE){
								printf("delete file name = %s\n",i_event[t].name);
								for(n=3; n<sizeof(name_to_fd)/sizeof(name_to_fd[0]); n++){
									if(strcmp(i_event[t].name,name_to_fd[n].name) == 0){
										close(name_to_fd[n].fd);
									}
								}
							}			
						}
					}
				}else{
					memset(buf,0,sizeof(buf));
					e_ret = read(revents[i].data.fd,buf,sizeof(buf));
					if(e_ret == -1){
						perror("read error");
						return -1;
					}
					printf("fd = %d,data = %s\n",revents[i].data.fd,buf);

				}
			}


		 }

	}

	return 0;
}
