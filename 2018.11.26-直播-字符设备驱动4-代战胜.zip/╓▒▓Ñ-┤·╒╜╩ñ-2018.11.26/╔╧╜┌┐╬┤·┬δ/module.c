#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>

struct cdev *cdev;

int major;
int minor;

int driver_open(struct inode *inode, struct file *file)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}

ssize_t driver_read(struct file *file, char __user * buf, size_t size, loff_t * offs)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}
ssize_t driver_write(struct file *file, const char __user *buf, size_t size, loff_t *offs)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}
int driver_release(struct inode *inode, struct file *file)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}

const struct file_operations fops = {
	.open    = driver_open,
	.write   = driver_write,
	.read    = driver_read,
	.release = driver_release,
};

static int __init demo_init(void)
{
	dev_t dev;
	//alloc cdev memory
	cdev = cdev_alloc();
	if(cdev == NULL){
		printk("cdev alloc memory fail\n");
		return -ENOMEM;
	}

	//init cdev
	cdev_init(cdev,&fops);

	//alloc device num
	//register_chrdev_region
	alloc_chrdev_region(&dev,0,3,"myled");
	//major = dev>>20;
	//minor = dev & (1<<20)-1;
	major = MAJOR(dev);
	minor = MINOR(dev);

	//register
	cdev_add(cdev,dev,3);
	

	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);
	return 0;
}

static void __exit demo_exit(void)
{
	printk("%s:%s:%d\n",__FILE__,__func__,__LINE__);

}



module_init(demo_init);
module_exit(demo_exit);
MODULE_LICENSE("GPL");
